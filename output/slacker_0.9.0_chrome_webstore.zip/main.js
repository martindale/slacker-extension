﻿function MyExtension() {
  var self = this;
}

var extension = new MyExtension();
